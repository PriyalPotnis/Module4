package pak1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LocatingElement {
static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException 
	{
		
	
	// 1.Launch Browser
	System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	// 2.Navigate to URL
	driver.get("file:///D:/Participants%20Material/Module%204/Demos/Lesson%202%20-%20Demos/HTML%20Pages/LocatingElements.html");
	
	// 3. Select value from Drop down
		//1. Find drop down
	WebElement wb1 = driver.findElement(By.id("country"));
	//create an obj of select class
	Select sel = new Select(wb1);
	//select value form drop down
	//sel.selectByVisibleText("USA");
	//sel.selectByValue("USA");
	sel.selectByIndex(3);
	driver.findElement(By.cssSelector("input#FN")).sendKeys("Priyal");
	driver.findElement(By.cssSelector("input#MN")).sendKeys("Potnis");
	driver.findElement(By.cssSelector("input#LN")).sendKeys("Potnis");
	driver.findElement(By.className("Format")).sendKeys("17/05/1995");
	
	//Thread.sleep(5000);
	//driver.close();
	
	
	}
	
}

