package pak1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FireFox {
public static void main(String[] args) {
	// 1.Launch Browser
	/*************** For Fire Fox Browser ******************/
	WebDriver driver = new FirefoxDriver();
	// 2.Navigate to URL
	driver.get("file:///D:/Participants%20Material/Module%204/Demos/Lesson%205-HTML%20Pages/WorkingWithForms.html");
	// 3.
}

}
