package pak1;

import net.sourceforge.htmlunit.corejs.javascript.ast.SwitchCase;

public class Sample{
	public final int var=12;
	public static void main(String[] args) {
		int ch=3;
		
		
	}
}