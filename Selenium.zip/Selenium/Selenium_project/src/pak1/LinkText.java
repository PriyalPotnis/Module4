package pak1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkText {
static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException 
	{
	
	// 1.Launch Browser
	System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	// 2.Navigate to URL
	driver.get("https://demo.opencart.com/");
	
	
	// 3.Enter Name
	driver.findElement(By.linkText("Desktops")).click();
	driver.findElement(By.linkText("Mac (1)")).click();
	Thread.sleep(2000);
	driver.navigate().back();
	Thread.sleep(2000);
	driver.navigate().forward();
	driver.navigate().to("https://www.google.co.in/?gfe_rd=cr&dcr=0&ei=jX9dWtLyDpDT8geE-InwBg");
	//driver.navigate().back();
	driver.findElement(By.id("lst-ib")).sendKeys("Selenium");
	Thread.sleep(4000);
	//driver.navigate().refresh();
	driver.navigate().back();

	}
}
