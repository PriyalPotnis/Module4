package grid;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class Class1Headless {
	public static void main(String[] args) {
		WebDriver driver = new HtmlUnitDriver();
		driver.get("https://demo.opencart.com/");
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Boolean title = driver.getTitle().contains("Your Store");	
		System.out.println(title);
	}
}
