package grid;



import java.net.MalformedURLException;
import java.net.URL;

import org.apache.xalan.Version;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Node {
	//static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException, MalformedURLException 
	{
		
	// 1.Launch Browser
	//System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	
	//DesiredCapabilities capability = DesiredCapabilities.chrome();
	DesiredCapabilities capability = DesiredCapabilities.firefox();
	//capability.setBrowserName("chrome");
	capability.setBrowserName("firefox");
	capability.setPlatform(Platform.ANY);
	WebDriver driver = new RemoteWebDriver(new URL("http://10.51.91.101:4444/wd/hub"), capability);
	try {
	driver.get("http://demo.opencart.com/");
	driver.manage().window().maximize();
	System.out.println(driver.getTitle());
	}
	catch(Exception ex){
	System.out.println("Hello");
	}
	}
	}