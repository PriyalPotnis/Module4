package grid;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class ClassHeadless {
	public static void main(String[] args) {
		WebDriver driver = new HtmlUnitDriver();
		driver.get("https://www.google.co.in/?gfe_rd=cr&dcr=0&ei=9nNlWtn7ApGmX6ifh6gN");
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Boolean title = driver.getTitle().contains("Sergei Eisenstein�s 120th birthday");
		Boolean title = driver.getTitle().contains("Google");
		
		System.out.println(title);
	}

}
