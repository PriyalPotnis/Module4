package testNGdemoPak;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Before {
  @BeforeTest
  public void a()  {
	  System.out.println("(BeforeTest)Login to application");
  }
//  @BeforeClass
//  public void bfrtest4() {
//	  System.out.println("(BeforeClass)Popat Server start");
//  }
  @Test
  public void Delete()
  {
	System.out.println("Deleting the records");  
  }
  @Test
  public void update()
  {
	  System.out.println("Updating the records");
  }
  @AfterTest
  public void afrtest1(){
	  System.out.println("(AfterTest)sLog OUT");
  }
 
  
}
