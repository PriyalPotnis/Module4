package testNGdemoPak;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Aftertest {

	@BeforeTest
	  public void rishi() {
		  System.out.println("(BeforeTest)Before test to application");
	  }
	@BeforeClass
	  public void bfrtest4() {
		  System.out.println("(BeforeClass)Server start");
	  }
	@Test
	public void bfrtest3() {
		  System.out.println("Test to application");
	  }
	
	//AfterMethod -> AfterClass -> AfterTest
	@AfterMethod
	public void afrtest1() {
		  System.out.println("(AfterMethod)After Method to application");
	  }
	
	@AfterTest
	  public void afrtest2() {
		  System.out.println("(AfterTest)After test to application");
	  }
	@AfterClass
	  public void afrtest3() {
		  System.out.println("(AfterClass)server close");
	  }
}
