package testNGdemoPak;

import org.testng.annotations.Test;

public class TestNGdemo2 {
  @Test
  public void insert() {
	  System.out.println("Inserting order");
  }
  @Test
  public void faxorder() {
	  System.out.println("Fax the order");
  }
  
}
