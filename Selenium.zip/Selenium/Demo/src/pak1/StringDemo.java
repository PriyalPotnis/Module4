package pak1;

class StringDemo{  
public static void main(String args[]){  
StringBuilder sb=new StringBuilder("Hello ");  
//sb.concat("Java");//now original string is changed  
System.out.println(sb);//prints Hello Java  
}  
}  