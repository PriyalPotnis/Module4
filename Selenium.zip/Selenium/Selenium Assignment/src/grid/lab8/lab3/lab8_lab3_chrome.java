package grid.lab8.lab3;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.chrome.ChromeDriver;

public class lab8_lab3_chrome {
	
	static WebDriver driver;
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	
	public static void main(String[] args) throws MalformedURLException {
		System.setProperty("webdriver.chrome.driver",driverpath+"chromedriver.exe");
		//driver = new ChromeDriver();
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setBrowserName("chrome");
		capabilities.setPlatform(Platform.ANY);
	
		driver = new RemoteWebDriver(new URL("http://10.51.91.73:4444/wd/hub"), capabilities);
	
	      
	      try {
	    		driver.get("http://demo.opencart.com/");
	    		driver.manage().window().maximize();
	    		System.out.println(driver.getTitle());
	    		//part1 1. LaunchApplication
	  	      //2. Verificaiton of title
	  	      String expectedTitle = "Your Store";
	  	      String actualTitle = driver.getTitle();
	  	      if(expectedTitle.equals(actualTitle))
	  	    	  System.out.println("Expected title is equal to Actual title");
	  	      else
	  	    	  System.out.println("Expected title is not equal to Actual Title");
	  	      
	  	      
	  	      //3. Click on My Account drop down
	  	      driver.findElement(By.linkText("My Account")).click();
	  	      
	  	      //4. select Register from drop down
	  	      driver.findElement(By.linkText("Register")).click();
	  	      
	  	      
	  	      //5.Verify the heading Register Account
	  	      String regacc = driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
	  	      String regacc1 = "Register Account";
	  	      if(regacc.equals(regacc1))
	  	    	  System.out.println("Expected heading is equal to actual heading");
	  	      else
	  	    	  System.out.println("Expected Heading is not equal to Actual Heading");
	  	      
	  	      //6. Click on 'Continue' button at the bottom of the page
	  	      driver.findElement(By.cssSelector("input[value='Continue']")).click();
	  	      
	  	      //7. verify warning message
	  	      String actualWarn = driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText();
	          String expectedWarn = "Warning: You must agree to the Privacy Policy!";
	          if(actualWarn.equals(expectedWarn))
	        	  System.out.println("Warning is verified");
	          else
	        	  System.out.println("Warning is not verified");
	          
	          driver.findElement(By.linkText("My Account")).click();
	  		driver.findElement(By.linkText("Register")).click();	
	  		
	  		/******************---PART 2--- For 'Your Personal Details'*********************************************/
	  		driver.findElement(By.name("agree")).click();
	  		//1. Enter data in 'First Name' text box
	  		driver.findElement(By.id("input-firstname")).sendKeys("abcdefghijklmnopqrstuvwxyz1234567");
	  		driver.findElement(By.cssSelector("input[value='Continue']")).click();
	  		//2. Verify if 33 characters can be entered in firstname
	  		
	  		WebElement wb = driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div"));
	  		String firstName = wb.getText();
	          System.out.println(firstName);
	          boolean firstName1=firstName.equals("First Name must be between 1 and 32 characters!");
	          //System.out.println(firstName.equals("First Name must be between 1 and 32 characters!"));
	          //3. if not verify error message
	          if(firstName1==true)	
	          	System.out.println("First Name is Verified");
	          else
	          	System.out.println("First Name is Not Verified");
	         
	          
	  		driver.findElement(By.cssSelector("input[value='Continue']")).click();
	  				
	  		//4. Enter data in 'Last Name' text box
	  		driver.findElement(By.id("input-lastname")).sendKeys("abcdefghijklmnopqrstuvwxyz1234567");
	  		
	  		//5. Verify if 33 characters can be entered in lastname
	  		WebElement wb2 = driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div"));
	  		String lastName = wb2.getText();
	          System.out.println(lastName);
	          
	          boolean lastName1=lastName.equals("Last Name must be between 1 and 32 characters!");
	          //6. If not verify error message
	          if(lastName1==true)	
	          System.out.println("Last Name is Verified");
	          else
	          	System.out.println("Last Name is Not Verified");
	  		
	  		//7. Enter valid 'E-mail'.
	  		driver.findElement(By.id("input-email")).sendKeys("priyal20@gmail.com");
	  		
	  		//8. Enter 'Telephone' which must be between 3 and 32 characters
	  		driver.findElement(By.name("telephone")).sendKeys("9170519950");
	  		
	  		driver.findElement(By.cssSelector("input[value='Continue']")).click();
	          /******************** Part 3 ************************/
	  		
	  		driver.findElement(By.linkText("My Account")).click();
	  		driver.findElement(By.linkText("Login")).click();
	  		driver.findElement(By.id("input-email")).sendKeys("priyal20@gmail.com");
	  		driver.findElement(By.id("input-password")).sendKeys("priyal123");
	  		driver.findElement(By.cssSelector("input[value='Login']")).click();
	  		
	  		driver.findElement(By.linkText("Modify your address book entries")).click();
	  		driver.findElement(By.linkText("New Address")).click();
	  		
	          //1. Enter 'Address 1' which should contain characters between 3 and 128
	          driver.findElement(By.xpath("//*[@id='input-address-1']")).sendKeys("CapGemini");
	          
	          //2. Enter 'city' which hould contain characters between 2 and 128
	          driver.findElement(By.xpath("//*[@id='input-city']")).sendKeys("Bangalore");
	          
	          //3. Enter 'post code' which should contain characters between 2 and 10
	          driver.findElement(By.id("input-postcode")).sendKeys("523240");
	          
	          //4. Select 'India' from Country' Drop down
	          WebElement country = driver.findElement(By.xpath("//*[@id='input-country']"));
	  		Select s = new Select(country);
	  		s.selectByVisibleText("India");
	  		//s.selectByIndex(99);
	  		
	  		//5. Select 'Region/State from dropdown list

	      	driver.findElement(By.xpath("//*[@id='input-zone']"));
	      	driver.findElement(By.linkText("Logout")).click();
	      	
	      	/******************* part 4*****************************/
	      	driver.findElement(By.linkText("My Account")).click();
	  		driver.findElement(By.linkText("Register")).click();
	  	
	  		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Priyal");
	  	
	  		driver.findElement(By.xpath("//input[@id='input-lastname']")).sendKeys("Potnis");
	  		driver.findElement(By.id("input-email")).sendKeys("priyal91@gmail.com");
	  		
	  		driver.findElement(By.name("telephone")).sendKeys("9170519950");


	  		/********FOR 'Password'************/
	  		//1. Enter 'Password' which must be between 4 and 20 characters.
	  		driver.findElement(By.id("input-password")).sendKeys("priyal123");
	  	
	  		//2. Enter 'Password' Confirm
	  		driver.findElement(By.cssSelector("input#input-confirm")).sendKeys("priyal123");

	  		/********FOR 'Newsletter'**********/
	  		//1. Click on 'Yes' Radio button
	  		driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[1]/input")).click();
	  		
	  		//2. Click on checkbox for 'I have read and agree to the Privacy Policy
	  		driver.findElement(By.name("agree")).click();
	  		
	  		//3. Click on 'Continue' button
	  		driver.findElement(By.cssSelector("input[value='Continue']")).click();

	  		//4. Verify message 'Your Account Has Been Created!'
	  		WebElement wb3 = driver.findElement(By.xpath("//*[@id='content']/h1"));
	  		String expectedtitle = "Your Account Has Been Created!";
	  		String actualtitle = wb3.getText();
	  		System.out.println(actualtitle);
	  		if(expectedtitle.equals(actualtitle)){
	  			System.out.println("Account has created");
	  		}
	  		else{
	  			System.out.println("Account has not created");
	  		}
	  		
	  		//5. Click on Continue
	  		driver.findElement(By.xpath("html/body/div[2]/div/div/div/div/a")).click();
	  		
	  		 //6. Click on link 'View your order history under 'My orders'
	  	      driver.findElement(By.xpath("html/body/div[2]/div/div/ul[2]/li[1]/a")).click();

	  	      //Close Browser
	  	      driver.close();
	    		}
	    		catch(Exception ex){
	    		System.out.println("Hello");
	    		}
	    		}
	    		
	}


