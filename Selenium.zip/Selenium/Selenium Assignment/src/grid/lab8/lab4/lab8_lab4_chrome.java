package grid.lab8.lab4;



import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.xalan.Version;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class lab8_lab4_chrome {
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	public static void main(String[] args) throws InterruptedException, MalformedURLException 
	{
		
	// 1.Launch Browser
	System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
	
	DesiredCapabilities capability = DesiredCapabilities.chrome();
	//DesiredCapabilities capability = DesiredCapabilities.firefox();
	capability.setBrowserName("chrome");
	//capability.setBrowserName("firefox");
	capability.setPlatform(Platform.ANY);
	WebDriver driver = new RemoteWebDriver(new URL("http://10.51.91.73:4444/wd/hub"), capability);
	try {
	driver.get("http://demo.opencart.com/");
	driver.manage().window().maximize();
	System.out.println(driver.getTitle());
	driver.findElement(By.linkText("My Account")).click();
	
	//1. Login with credentials created in Lab1
	driver.findElement(By.linkText("Login")).click();
	driver.findElement(By.id("input-email")).sendKeys("priyal20@gmail.com");
	driver.findElement(By.id("input-password")).sendKeys("priyal123");
	driver.findElement(By.cssSelector("input[value='Login']")).click();
	
	//2. Go to 'Components' tab and click
	driver.findElement(By.linkText("Components")).click();
	
	//3. Select 'Monitors'
	driver.findElement(By.linkText("Monitors (2)")).click();
	
	//4. Select 25 from 'Show' dropdown
	WebElement wb = driver.findElement(By.id("input-limit"));
	Select s = new Select(wb);
	s.selectByVisibleText("25");
	
	//5. Click on 'Add to cart' from the first item
	driver.findElement(By.xpath("//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
	
	//Implicit wait
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	//6. Click on 'Specification' tab
	driver.findElement(By.xpath("//*[@id='content']/div[1]/div[1]/ul[2]/li[2]/a")).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	//7. Verify details present on the page
	if(driver.getPageSource().contains("100mhz"))
         System.out.println("The clock speed is in customer specification");
     else
    	 System.out.println("The clock speed is not reached to customer specification");
	
	//8. click on 'Add to Wish list' button.
	driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div[1]/button[1]")).click();
	
	//9. Verify message 'Success: You have added Apple Cinema 30 to your wish list!'
	WebElement sucmsg = driver.findElement(By.xpath("//*[@id='product-product']/div[1]"));
    //System.out.println(sucmsg);
    String altmsg = "Success: You have added ";
    
     if(sucmsg.equals(altmsg))
    	 System.out.println("It is added to cart");
     else
    	 System.out.println("It is not added to cart");
    
    //10. Enter 'Mobile' in 'Search' text box
	driver.findElement(By.name("search")).sendKeys("Mobile");
	
	//11. Click on 'Search' button
	driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
	
	//12. Click on 'Search in product descriptions' check box
	driver.findElement(By.id("description")).click();
	driver.findElement(By.id("input-search")).clear();
	
	//13. Click on link 'HTC Touch HD' for the moblie 'HTC Touch HD'
	driver.findElement(By.id("input-search")).sendKeys("HTC Touch HD");
	driver.findElement(By.id("button-search")).click();
	driver.findElement(By.className("img-responsive")).click();
	
	//14. Clear '1' from 'Qty'
	driver.findElement(By.id("input-quantity")).clear();
	
	// enter Qty as '3'
	driver.findElement(By.id("input-quantity")).sendKeys("3");
	
	//15. Add to Cart
	driver.findElement(By.id("button-cart")).click();
	
	//16. Verify Success message
	String sucmsg1 = driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText();
    if(sucmsg1.contains("Success"))
    	System.out.println("Success message came");
    else
    	System.out.println("Success message did not come");
    
    //17. View Cart
	driver.findElement(By.id("cart-total")).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[1]/strong")).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	//18. Verify Mobile name
	String string = "HTC Touch HD";
    String string1 = driver.findElement(By.linkText("HTC Touch HD")).getText();
  
     if(string.equals(string1))
    	 System.out.println("Verified");
     else
    	 System.out.println("Not verified");
	//19. click on Checkout
	driver.findElement(By.xpath("//*[@id='content']/div[3]/div[2]/a")).click();
	//20. click on MyAccount dropdown
	driver.findElement(By.linkText("My Account")).click();
	//21. click on Logout
	driver.findElement(By.linkText("Logout")).click();
	
	//22. Verify Account Logout
    String expectedHead = "Account Logout";
    WebElement actualHead = driver.findElement(By.xpath("//*[@id='content']/h1"));
    
    
    if(expectedHead.equals(actualHead.getText()))
         System.out.println("Account Logout is verified");
    else
    	System.out.println("Account logout is not verified");
	driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
	//23. Click on Continue
	driver.findElement(By.linkText("Continue")).click();
	//driver.findElement(By.className("btn btn-primary")).click();
	driver.close();
	}
	catch(Exception ex){
	System.out.println("Hello");
	}
	}
	}