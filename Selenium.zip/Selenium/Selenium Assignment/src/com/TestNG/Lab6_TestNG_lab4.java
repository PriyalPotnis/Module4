package com.TestNG;



import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Lab6_TestNG_lab4 {
	static WebDriver driver;
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	@BeforeClass
	public static void launching(){
		
		//step1 launching the browser
		 //driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
		driver = new ChromeDriver();
		
		//step2 navigate to application
		driver.navigate().to("http://demo.opencart.com/");
		driver.manage().window().maximize();
	}
	@BeforeTest
	public void init(){
		System.out.println("Before");
	}
	@Test
	public void test1() {
		driver.findElement(By.linkText("My Account")).click();
		//Login with credentials created in Lab1
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.id("input-email")).sendKeys("priyal20@gmail.com");
		driver.findElement(By.id("input-password")).sendKeys("priyal123");
		driver.findElement(By.cssSelector("input[value='Login']")).click();
		//Go to 'Components' tab and click
		driver.findElement(By.linkText("Components")).click();
		//Select 'Monitors'
		driver.findElement(By.linkText("Monitors (2)")).click();
		//Select 25 from 'Show' dropdown
		WebElement wb = driver.findElement(By.id("input-limit"));
		Select s = new Select(wb);
		s.selectByVisibleText("25");
		//Click on 'Add to cart' from the first item
		driver.findElement(By.xpath("//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
		//Implicit wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Click on 'Specification' tab
		driver.findElement(By.xpath("//*[@id='content']/div[1]/div[1]/ul[2]/li[2]/a")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Page Details check
		AssertJUnit.assertEquals("https://demo.opencart.com/index.php?route=product/product&product_id=42", driver.getCurrentUrl());
		System.out.println("Page Source verified");
	}
	
	@Test
	public void test2() {
		//click on 'Add to Wish list' button.
				driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div[1]/button[1]")).click();
				//Verify message 'Success: You have added Apple Cinema 30" to your wish list!'
				Assert.assertNotEquals("Success: You have added",driver.findElement(By.xpath("//*[@id='product-product']/div[1]")).getText());
				System.out.println("Add to wish list message verified");
	}
	
	@Test
	public void test3() {
				//Enter 'Mobile' in 'Search' text box
				driver.findElement(By.name("search")).sendKeys("Mobile");
				//Click on 'Search' button
				driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
				//Click on 'Search in product descriptions' check box
				driver.findElement(By.id("description")).click();
				driver.findElement(By.id("input-search")).clear();
				//Click on link 'HTC Touch HD' for the moblie 'HTC Touch HD'
				driver.findElement(By.id("input-search")).sendKeys("HTC Touch HD");
				driver.findElement(By.id("button-search")).click();
				driver.findElement(By.className("img-responsive")).click();
				//Clear '1' from 'Qty'
				driver.findElement(By.id("input-quantity")).clear();
				//enter Qty as '3'
				driver.findElement(By.id("input-quantity")).sendKeys("3");
				//Add to Cart
				driver.findElement(By.id("button-cart")).click();
				Assert.assertNotEquals("Success", driver.findElement(By.xpath("//*[@id='product-product']/div[1]")).getText());
				System.out.println("Add to cart message verified");
	}

	@Test
	public void test4(){
		//View Cart
				driver.findElement(By.id("cart-total")).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[1]/strong")).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
		//verify Mobile name
		AssertJUnit.assertEquals("HTC Touch HD",driver.findElement(By.linkText("HTC Touch HD")).getText());
		System.out.println("Verified Mobile Name");
		//click on Checkout
		driver.findElement(By.xpath("//*[@id='content']/div[3]/div[2]/a")).click();
	}
	@Test
	public void test5(){
	
				
				//click on MyAccount dropdown
				driver.findElement(By.linkText("My Account")).click();
				//click on Logout
				driver.findElement(By.linkText("Logout")).click();
				//Verify Account Logout
				AssertJUnit.assertEquals("Account Logout", driver.findElement(By.xpath("//*[@id='content']/h1")).getText());	
				System.out.println("Account logout");
	}
	@AfterTest
	public void destroy(){
		System.out.println("After");
	}
}
