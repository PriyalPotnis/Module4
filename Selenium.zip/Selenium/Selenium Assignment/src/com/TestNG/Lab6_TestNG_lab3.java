package com.TestNG;



import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Lab6_TestNG_lab3 {
	
	static WebDriver driver;
	static String driverpath = "D:\\VNV Software\\Selenium\\WebDrivers\\";
	@BeforeClass
	public static void launching(){
		
		//step1 launching the browser
		 //driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver", driverpath+ "chromedriver.exe");
		driver = new ChromeDriver();
		
		//step2 navigate to application
		driver.navigate().to("http://demo.opencart.com/");
		driver.manage().window().maximize();
	}
	@BeforeTest
	public void init(){
		System.out.println("Before");
	}
	
	/************************** Part 1 ******************************************/
  @Test
  public void test1() throws InterruptedException{
	  
	 //Verify Title
	  AssertJUnit.assertEquals("Your Store", driver.getTitle());
	  System.out.println("Title is verified");
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      
  }		
	@Test	
  public void test2(){
	//Click on My Account drop down
      driver.findElement(By.linkText("My Account")).click();
      
      //Select Register from drop down
      driver.findElement(By.linkText("Register")).click();
    //Verify Register Heading
	  AssertJUnit.assertEquals("Register Account", driver.findElement(By.xpath("//*[@id='content']/h1")).getText());
	  System.out.println("Register Heading is verified");
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
  }
	
	@Test
	public void test3(){
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
		//Verify Register message
		AssertJUnit.assertEquals("Warning: You must agree to the Privacy Policy!", driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText());
		System.out.println("Verification message is verified");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	/*************************************Part 2****************************************************************************************************/
  
	@Test
	public void test4(){
		driver.findElement(By.name("agree")).click();
		//Enter data in 'First Name' text box
		driver.findElement(By.id("input-firstname")).sendKeys("abcdefghijklmnopqrstuvwxyz1234567");
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
		
		//Verify characters in firstname
		AssertJUnit.assertEquals("First Name must be between 1 and 32 characters!",driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div")).getText());
		System.out.println("FirstName is verified for more than 32 characters");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Test
	public void test5(){

		//Enter data in 'Last Name' text box
		driver.findElement(By.id("input-lastname")).sendKeys("abcdefghijklmnopqrstuvwxyz1234567");
		
		//Verify characters in lastname
		AssertJUnit.assertEquals("Last Name must be between 1 and 32 characters!",driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div")).getText());
		System.out.println("LastName is verified for more than 32 characters");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Test
	public void test6(){
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.linkText("Register")).click();
	
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Priyal");
	
		driver.findElement(By.xpath("//input[@id='input-lastname']")).sendKeys("Potnis");
		driver.findElement(By.id("input-email")).sendKeys("priyal80@gmail.com");
		
		driver.findElement(By.name("telephone")).sendKeys("9170519950");

		/**********************PART 4****************************************************************************/
		
		/********FOR 'Password'************/
		//Enter 'Password' which must be between 4 and 20 characters.
		driver.findElement(By.id("input-password")).sendKeys("priyal123");
	
		//Enter 'Password' Confirm
		driver.findElement(By.cssSelector("input#input-confirm")).sendKeys("priyal123");

		/********FOR 'Newsletter'**********/
		//Click on 'Yes' Radio button
		driver.findElement(By.xpath("//*[@id='content']/form/fieldset[3]/div/div/label[1]/input")).click();
		
		//Click on checkbox for 'I have read and agree to the Privacy Policy
		driver.findElement(By.name("agree")).click();
		
		//Click on 'Continue' button
		driver.findElement(By.cssSelector("input[value='Continue']")).click();
		
		//Verify Account creation message
		AssertJUnit.assertEquals("Register Account",driver.findElement(By.xpath("//*[@id='content']/h1")).getText());
		System.out.println("Account creation message is verified");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
	@AfterClass
  public static void closing(){
      driver.close();
  }
  @AfterTest
	public void destroy(){
		System.out.println("After");
	}
}
